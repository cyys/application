path = 'C:\\Users\\pros_cy\\Desktop\\1'
rmDir = 'target'
endDir = 'src'

import os,sys

def findAllRmDir(path, targetDirs):
    targetParentDirs = []
    for p, dirs, fs in os.walk(path):
        if rmDir in dirs:
            targetDirs.append('\\'.join([p, rmDir]))
            targetParentDirs.append(p)
        elif endDir in dirs:
            continue
        else:
            for dir in dirs:
                findAllRmDir('\\'.join([p, dir]), targetDirs)
    return targetParentDirs


def removeDir(paths):
    for ph in paths:
        for p, dirs, fs in os.walk(ph):
            if len(fs) > 0:
                for f in fs:
                    os.remove('\\'.join([p, f]))
            if len(dirs) > 0:
                removeDir(dirs)
            else:
                os.rmdir(p)

def removeAllDir(path):
    targetDirs = []
    targetParentDirs = findAllRmDir(path, targetDirs)
    removeDir(targetDirs)
    if len(targetDirs) > 0:
        for pt in targetParentDirs:
            removeAllDir(pt)

if __name__ == '__main__':
    args=sys.argv
    if len(args)>1:
        path=args[1]
    if len(args)>2:
        rmDir=args[2]
    if len(args)>3:
        endDir=args[3]
    print(args)
    removeAllDir(path)
    print ('删除目录\"' + rmDir + '\"成功！')
