__author__ = 'CHENYUANYINGSHI'

def batchViewHtml():
    import  readSetTime as rt
    import  readHtmlFile as rf
    import  parseHtml as ph
    import  DataAnalysis as da
    import  viewHtml as vh

    # import  app.readSetTime as rt
    # import  app.readHtmlFile as rf
    # import  app.parseHtml as ph
    # import  app.DataAnalysis as da
    # import  app.viewHtml as vh

    import datetime

    gapTime=rt.readGapTime()
    gapSub=datetime.timedelta(days=gapTime['timeGap'])
    subTime=datetime.timedelta(days=1)

    t={'endTime':gapTime['endTime']}
    t['beginTime']=t['endTime']-gapSub
    t['HtmlDir']=gapTime['HtmlDir']
    t['resultDir']=gapTime['resultDir']

    while(True):
        htmlFiles=rf.readHtmlFile(t)
        results=ph.parsehtmlFile(htmlFiles)
        lastNumType=da.dataAnalysis(results)
        vh.viewHtml(lastNumType,'../result/'+gapTime['resultDir']+'/'+str(t['beginTime'])+'_'+str(t['endTime'])+'.html')

        if t['beginTime']<=gapTime['beginTime']:
            break;
        else:
            t['endTime']=t['endTime']-subTime
            t['beginTime']=t['endTime']-gapSub

    return True



if __name__=='__main__':
    print(batchViewHtml())