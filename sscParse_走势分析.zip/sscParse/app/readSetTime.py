__author__ = 'CHENYUANYINGSHI'

def readTime():
    import configparser,datetime
    parse=configparser.ConfigParser()
    parse.read('../data/input.ini')
    t={}
    try:
        beginTime=parse.get('TIME','beginTime').split('-')
        endTime=parse.get('TIME','endTime').split('-')
        t['HtmlDir']=parse.get('TIME','HtmlDir')
        t['resultDir']=parse.get('TIME','resultDir')

        t['beginTime']=datetime.date(int(beginTime[0]),int(beginTime[1]),int(beginTime[2]))
        t['endTime']=datetime.date(int(endTime[0]),int(endTime[1]),int(endTime[2]))
    except:
        raise '日期格式不合法，如：2016-09-28'

    if t['beginTime']>t['endTime']:
        raise '开始时间不可在结束时间之后！'

    return t

def readGapTime():
    import configparser,datetime
    parse=configparser.ConfigParser()
    parse.read('../data/input.ini')
    t={}
    try:
        beginTime=parse.get('GAP_TIME','beginTime').split('-')
        endTime=parse.get('GAP_TIME','endTime').split('-')

        t['beginTime']=datetime.date(int(beginTime[0]),int(beginTime[1]),int(beginTime[2]))
        t['endTime']=datetime.date(int(endTime[0]),int(endTime[1]),int(endTime[2]))
        t['HtmlDir']=parse.get('GAP_TIME','HtmlDir')
        t['resultDir']=parse.get('GAP_TIME','resultDir')

    except:
        raise '日期格式不合法，如：2016-09-28'

    if t['beginTime']>t['endTime']:
        raise '开始时间不可在结束时间之后！'

    try:
        t['timeGap']=int(parse.get('GAP_TIME','timeGap'))
    except:
        raise '时间间隔不能为小数！'

    if t['timeGap']<0:
            raise '时间间隔不能为负数！'

    return t

if __name__=='__main__':
    print(readTime())
    print(readGapTime())
