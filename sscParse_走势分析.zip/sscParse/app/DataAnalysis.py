__author__ = 'CHENYUANYINGSHI'

def dataAnalysis(data=None):
    if not data:
        import parseHtml as resultData
        data=resultData.parsehtmlFile()

    curTrData=None
    prevTime=None
    isHasQuShi=False
    results=None

    curNumType={'WAN_OU':0,'WAN_JI':0,'WAN_DA':0,'WAN_XIAO':0,
                'QIAN_OU':0,'QIAN_JI':0,'QIAN_DA':0,'QIAN_XIAO':0,
                'BAI_OU':0,'BAI_JI':0,'BAI_DA':0,'BAI_XIAO':0,
                'SHI_OU':0,'SHI_JI':0,'SHI_DA':0,'SHI_XIAO':0,
                'GE_OU':0,'GE_JI':0,'GE_DA':0,'GE_XIAO':0
                }

    lastNumType={'WAN_OU':0,'WAN_JI':0,'WAN_DA':0,'WAN_XIAO':0,
                'QIAN_OU':0,'QIAN_JI':0,'QIAN_DA':0,'QIAN_XIAO':0,
                'BAI_OU':0,'BAI_JI':0,'BAI_DA':0,'BAI_XIAO':0,
                'SHI_OU':0,'SHI_JI':0,'SHI_DA':0,'SHI_XIAO':0,
                'GE_OU':0,'GE_JI':0,'GE_DA':0,'GE_XIAO':0,

                'WAN_OU_ZS':0,'WAN_JI_ZS':0,'WAN_DA_ZS':0,'WAN_XIAO_ZS':0,
                'QIAN_OU_ZS':0,'QIAN_JI_ZS':0,'QIAN_DA_ZS':0,'QIAN_XIAO_ZS':0,
                'BAI_OU_ZS':0,'BAI_JI_ZS':0,'BAI_DA_ZS':0,'BAI_XIAO_ZS':0,
                'SHI_OU_ZS':0,'SHI_JI_ZS':0,'SHI_DA_ZS':0,'SHI_XIAO_ZS':0,
                'GE_OU_ZS':0,'GE_JI_ZS':0,'GE_DA_ZS':0,'GE_XIAO_ZS':0,'TOTAL_QI_SHU':0,

                'QU_SHI_TOTAL':0,'QU_SHI_TOTAL_QI_SHU':0,'QU_SHI_MAX_QI_SHU':0,'QU_SHI_SUM_QI_SHU':0
                }
    #可投注走势总数 QU_SHI_TOTAL 可投注走势累计期数 QU_SHI_TOTAL_QI_SHU 可投注走势期数 QU_SHI_SUM_QI_SHU 最大的走势期数 QU_SHI_MAX_QI_SHU

    allData=data['results']
    trHtml=''
    tempTr=None
    while len(allData)>0:
        curTrData=allData.pop()
        tempTr='<tr>'

        isHasQuShi=False
        if prevTime==1 and curTrData['HOUR']==10 :
            curNumType={'WAN_OU':0,'WAN_JI':0,'WAN_DA':0,'WAN_XIAO':0,
                'QIAN_OU':0,'QIAN_JI':0,'QIAN_DA':0,'QIAN_XIAO':0,
                'BAI_OU':0,'BAI_JI':0,'BAI_DA':0,'BAI_XIAO':0,
                'SHI_OU':0,'SHI_JI':0,'SHI_DA':0,'SHI_XIAO':0,
                'GE_OU':0,'GE_JI':0,'GE_DA':0,'GE_XIAO':0
                }

        #万位
        results=analysisNumber({'curTrData':curTrData,'position':'WAN','numType':'JO','curNumType':curNumType,'lastNumType':lastNumType})
        isHasQuShi=results['isHasQuShi']
        tempTr+='<td>'+results['trHtml']
        results=analysisNumber({'curTrData':curTrData,'position':'WAN','numType':'DX','curNumType':curNumType,'lastNumType':lastNumType})
        isHasQuShi=results['isHasQuShi'] or isHasQuShi
        tempTr+=results['trHtml']+'</td>'

        #千位
        results=analysisNumber({'curTrData':curTrData,'position':'QIAN','numType':'JO','curNumType':curNumType,'lastNumType':lastNumType})
        isHasQuShi=results['isHasQuShi'] or isHasQuShi
        tempTr+='<td>'+results['trHtml']
        results=analysisNumber({'curTrData':curTrData,'position':'QIAN','numType':'DX','curNumType':curNumType,'lastNumType':lastNumType})
        isHasQuShi=results['isHasQuShi'] or isHasQuShi
        tempTr+=results['trHtml']+'</td>'

        #百位
        results=analysisNumber({'curTrData':curTrData,'position':'BAI','numType':'JO','curNumType':curNumType,'lastNumType':lastNumType})
        isHasQuShi=results['isHasQuShi'] or isHasQuShi
        tempTr+='<td>'+results['trHtml']
        results=analysisNumber({'curTrData':curTrData,'position':'BAI','numType':'DX','curNumType':curNumType,'lastNumType':lastNumType})
        isHasQuShi=results['isHasQuShi'] or isHasQuShi
        tempTr+=results['trHtml']+'</td>'

        #十位
        results=analysisNumber({'curTrData':curTrData,'position':'SHI','numType':'JO','curNumType':curNumType,'lastNumType':lastNumType})
        isHasQuShi=results['isHasQuShi'] or isHasQuShi
        tempTr+='<td>'+results['trHtml']
        results=analysisNumber({'curTrData':curTrData,'position':'SHI','numType':'DX','curNumType':curNumType,'lastNumType':lastNumType})
        isHasQuShi=results['isHasQuShi'] or isHasQuShi
        tempTr+=results['trHtml']+'</td>'

        #个位
        results=analysisNumber({'curTrData':curTrData,'position':'GE','numType':'JO','curNumType':curNumType,'lastNumType':lastNumType})
        isHasQuShi=results['isHasQuShi'] or isHasQuShi
        tempTr+='<td>'+results['trHtml']
        results=analysisNumber({'curTrData':curTrData,'position':'GE','numType':'DX','curNumType':curNumType,'lastNumType':lastNumType})
        isHasQuShi=results['isHasQuShi'] or isHasQuShi
        tempTr+=results['trHtml']+'</td>'

        tempTr+='</tr>'
        if len(tempTr)>54:
            trHtml=tempTr+trHtml

        if isHasQuShi:
            lastNumType['QU_SHI_SUM_QI_SHU']=lastNumType['QU_SHI_SUM_QI_SHU']+1

        prevTime=curTrData['HOUR']
        lastNumType['TOTAL_QI_SHU']+=1

    isHasQuShi=False
    positions=['WAN','QIAN','BAI','SHI','GE']
    for position in positions:
        isHasQuShi=oneTodayEnd(position,curNumType,lastNumType)

    if isHasQuShi:
        lastNumType['QU_SHI_SUM_QI_SHU']=lastNumType['QU_SHI_SUM_QI_SHU']+1

    return {'lastNumType':lastNumType,'resultDir':data['resultDir'],'trHtml':trHtml}

def oneTodayEnd(position,curNumType,lastNumType):
    isHasQuShi=False
    if curNumType[position+'_DA']>=4:
            lastNumType[position+'_DA']=max(lastNumType[position+'_DA'],curNumType[position+'_DA'])
            lastNumType['QU_SHI_TOTAL']=lastNumType['QU_SHI_TOTAL']+1
            lastNumType['QU_SHI_MAX_QI_SHU']=max(lastNumType['QU_SHI_MAX_QI_SHU'],lastNumType[position+'_DA'])
            lastNumType['QU_SHI_TOTAL_QI_SHU']=lastNumType['QU_SHI_TOTAL_QI_SHU']+curNumType[position+'_DA']
            lastNumType[position+'_DA_ZS']=lastNumType[position+'_DA_ZS']+1
            isHasQuShi=True
    if curNumType[position+'_XIAO']>=4:
            lastNumType[position+'_XIAO']=max(lastNumType[position+'_XIAO'],curNumType[position+'_XIAO'])
            lastNumType['QU_SHI_TOTAL']=lastNumType['QU_SHI_TOTAL']+1
            lastNumType['QU_SHI_MAX_QI_SHU']=max(lastNumType['QU_SHI_MAX_QI_SHU'],lastNumType[position+'_XIAO'])
            lastNumType['QU_SHI_TOTAL_QI_SHU']=lastNumType['QU_SHI_TOTAL_QI_SHU']+curNumType[position+'_XIAO']
            lastNumType[position+'_XIAO_ZS']=lastNumType[position+'_XIAO_ZS']+1
            isHasQuShi=True
    if curNumType[position+'_JI']>=4:
            lastNumType[position+'_JI']=max(lastNumType[position+'_JI'],curNumType[position+'_JI'])
            lastNumType['QU_SHI_TOTAL']=lastNumType['QU_SHI_TOTAL']+1
            lastNumType['QU_SHI_MAX_QI_SHU']=max(lastNumType['QU_SHI_MAX_QI_SHU'],lastNumType[position+'_JI'])
            lastNumType['QU_SHI_TOTAL_QI_SHU']=lastNumType['QU_SHI_TOTAL_QI_SHU']+curNumType[position+'_JI']
            lastNumType[position+'_JI_ZS']=lastNumType[position+'_JI_ZS']+1
            isHasQuShi=True
    if curNumType[position+'_OU']>=4:
            lastNumType[position+'_OU']=max(lastNumType[position+'_OU'],curNumType[position+'_OU'])
            lastNumType['QU_SHI_TOTAL']=lastNumType['QU_SHI_TOTAL']+1
            lastNumType['QU_SHI_MAX_QI_SHU']=max(lastNumType['QU_SHI_MAX_QI_SHU'],lastNumType[position+'_OU'])
            lastNumType['QU_SHI_TOTAL_QI_SHU']=lastNumType['QU_SHI_TOTAL_QI_SHU']+curNumType[position+'_OU']
            lastNumType[position+'_OU_ZS']=lastNumType[position+'_OU_ZS']+1
            isHasQuShi=True
    return isHasQuShi

#curTrData position numType curNumType lastNumType
def analysisNumber(options):
    curTrData=options['curTrData']
    curNumType=options['curNumType']
    lastNumType=options['lastNumType']
    position=options['position']
    isHasQuShi=False
    trHtml=''

    if options['numType']=='DX':
        #大 小性
        if curTrData[position]>=5:
            curNumType[position+'_DA']=curNumType[position+'_DA']+1
            if curNumType[position+'_XIAO']>=4:
                lastNumType[position+'_XIAO']=max(lastNumType[position+'_XIAO'],curNumType[position+'_XIAO'])
                lastNumType['QU_SHI_TOTAL']=lastNumType['QU_SHI_TOTAL']+1
                lastNumType['QU_SHI_MAX_QI_SHU']=max(lastNumType['QU_SHI_MAX_QI_SHU'],lastNumType[position+'_XIAO'])
                lastNumType['QU_SHI_TOTAL_QI_SHU']=lastNumType['QU_SHI_TOTAL_QI_SHU']+curNumType[position+'_XIAO']
                lastNumType[position+'_XIAO_ZS']=lastNumType[position+'_XIAO_ZS']+1
                isHasQuShi=True
                trHtml=oneWei('xiao',curNumType[position+'_XIAO']+1)
            curNumType[position+'_XIAO']=0
        else:
            curNumType[position+'_XIAO']=curNumType[position+'_XIAO']+1
            if curNumType[position+'_DA']>=4:
                lastNumType[position+'_DA']=max(lastNumType[position+'_DA'],curNumType[position+'_DA'])
                lastNumType['QU_SHI_TOTAL']=lastNumType['QU_SHI_TOTAL']+1
                lastNumType['QU_SHI_MAX_QI_SHU']=max(lastNumType['QU_SHI_MAX_QI_SHU'],lastNumType[position+'_DA'])
                lastNumType['QU_SHI_TOTAL_QI_SHU']=lastNumType['QU_SHI_TOTAL_QI_SHU']+curNumType[position+'_DA']
                lastNumType[position+'_DA_ZS']=lastNumType[position+'_DA_ZS']+1
                isHasQuShi=True
                trHtml=oneWei('da',curNumType[position+'_DA']+1)
            curNumType[position+'_DA']=0
    else:#奇 偶性
        if curTrData[position]%2==0:
            curNumType[position+'_OU']=curNumType[position+'_OU']+1
            if curNumType[position+'_JI']>=4:
                lastNumType[position+'_JI']=max(lastNumType[position+'_JI'],curNumType[position+'_JI'])
                lastNumType['QU_SHI_TOTAL']=lastNumType['QU_SHI_TOTAL']+1
                lastNumType['QU_SHI_MAX_QI_SHU']=max(lastNumType['QU_SHI_MAX_QI_SHU'],lastNumType[position+'_JI'])
                lastNumType['QU_SHI_TOTAL_QI_SHU']=lastNumType['QU_SHI_TOTAL_QI_SHU']+curNumType[position+'_JI']
                lastNumType[position+'_JI_ZS']=lastNumType[position+'_JI_ZS']+1
                isHasQuShi=True
                trHtml=oneWei('dan',curNumType[position+'_JI']+1)
            curNumType[position+'_JI']=0
        else:
            curNumType[position+'_JI']=curNumType[position+'_JI']+1
            if curNumType[position+'_OU']>=4:
                lastNumType[position+'_OU']=max(lastNumType[position+'_OU'],curNumType[position+'_OU'])
                lastNumType['QU_SHI_TOTAL']=lastNumType['QU_SHI_TOTAL']+1
                lastNumType['QU_SHI_MAX_QI_SHU']=max(lastNumType['QU_SHI_MAX_QI_SHU'],lastNumType[position+'_OU'])
                lastNumType['QU_SHI_TOTAL_QI_SHU']=lastNumType['QU_SHI_TOTAL_QI_SHU']+curNumType[position+'_OU']
                lastNumType[position+'_OU_ZS']=lastNumType[position+'_OU_ZS']+1
                isHasQuShi=True
                trHtml=oneWei('shuang',curNumType[position+'_OU']+1)
            curNumType[position+'_OU']=0

    return {'isHasQuShi':isHasQuShi,'trHtml':trHtml}

def oneWei(type,num):
    styleClass=None
    if type=='shuang':
        styleClass='<span class="'+type+'">'+'双['+str(num)+']</span>'
    elif type=='dan':
        styleClass='<span class="'+type+'">'+'单['+str(num)+']</span>'
    elif type=='da':
        styleClass='【<span class="'+type+'">'+'大['+str(num)+']</span>】'
    else:
        styleClass='【<span class="'+type+'">'+'小['+str(num)+']</span>】'

    return styleClass

if __name__=='__main__':
    print(dataAnalysis())