__author__ = 'CHENYUANYINGSHI'
import xml.sax as sax
class htmlFile(sax.ContentHandler):

    def __init__(self):
        self._tdIndex=0
        self.content=''
        self.curTr=None
        self.trList=[]
        self.errorMsg=None


    def startElement(self, name, attrs):
         if name=='td':
            self._tdIndex=self._tdIndex+1
            if self._tdIndex%19==1:
                self.curTr={}
                self.trList.append(self.curTr)

    def endElement(self,tag):
        if tag=='td' :
            n=self._tdIndex%19
            if n>1 and n<8:
                if n==2:
                    self.curTr['HOUR']=int(self.content.split(':')[0])
                elif n==3:
                    self.curTr['WAN']=int(self.content)
                elif n==4:
                    self.curTr['QIAN']=int(self.content)
                elif n==5:
                    self.curTr['BAI']=int(self.content)
                elif n==6:
                    self.curTr['SHI']=int(self.content)
                elif n==7:
                    self.curTr['GE']=int(self.content)



    def characters(self, content):
        self.content=content

    def endDocument(self):
        if self._tdIndex/19!=120:
            self.errorMsg= '记录条数为'+str(self._tdIndex/19)+'条，应该为120条！请核对记录是否正确！'

    def getErroMsg(self):
        return self.errorMsg

    def getParseReult(self):
        return self.trList

def parsehtmlFile(data=None):
    parse=sax.make_parser()
    parse.setFeature(sax.handler.feature_namespaces, 0)

    if not data:
        import readHtmlFile as readFile
        data=readFile.readHtmlFile()
    handler=None
    results=None
    fileName=None

    try:
        for f in data['htmlFiles'] :
            fileName=f.split('/')
            fileName=fileName[len(fileName)-1]
            handler=htmlFile()
            parse.setContentHandler(handler)
            parse.parse(f)
            if not results:
                results=handler.getParseReult()
            else:
                results.extend(handler.getParseReult())
            if handler.getErroMsg():
                print('文件：'+fileName+','+handler.getErroMsg())
                # raise RuntimeError('记录条数不对！')
    except RuntimeError as r:
        raise r
    except:
        print('文件：'+fileName+',不存在!')
        raise '请确保文件存在！'

    return  {'results':results,'resultDir':data['resultDir']}

if __name__=='__main__':
    print(len(parsehtmlFile()))