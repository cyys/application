__author__ = 'CHENYUANYINGSHI'
def readHtmlFile(t=None):
    import datetime
    if not t:
        import readSetTime as rt
        t=rt.readTime()
    subTime=datetime.timedelta(days=1)
    curime=t['endTime']
    htmlFiles=[]
    while curime>=t['beginTime']:
        htmlFiles.append('../html/'+t['HtmlDir']+'/'+str(curime)+'.xml')
        curime=curime-subTime
    return {'htmlFiles':htmlFiles,'resultDir':t['resultDir']}

if __name__=='__main__':
    print(readHtmlFile())



