if __name__=='__main__':
	import os,sys
	
	fileName='environParam.txt'
	filter='C:'
	
	HOME='HOME'
	PATH='PATH'
	CLASSPATH='CLASSPATH'
	WORD=':'
	EQUAL='='
	SPLIT=';'
	
	if len(sys.argv)>1:
		fileName=sys.argv[1]
	if len(sys.argv)>2:
		filter=sys.argv[2]	 
	fp=open(fileName,'w')	
	map=os.environ
	strings={}
	path=None
	classPath=None
	for k,v in map.items():
		if (v.rfind(filter.upper())<0 or k.rfind(HOME)>0 or k==PATH) and v.rfind(WORD)>0:	
			if k==PATH:
				path=v		
			elif k==CLASSPATH:
				classPath=v
			else:				
				param=EQUAL.join([k,v])
				#print(param)
				strings[k]=v
				fp.write(param+'\n')
				
	for k,v in strings.items():
		path=path.replace(v,'%'+k+'%')
		classPath=classPath.replace(v,'%'+k+'%')

	paths=[]
	ps=path.split(SPLIT)
	for p in ps:
		if p.rfind(filter.upper())<0:
			paths.append(p)
	path=PATH+EQUAL+SPLIT.join(paths)
	classPath=CLASSPATH+EQUAL+classPath
	#print(path)	
	fp.write(classPath+'\n')
	fp.write(path+'\n')	 	
	fp.close()