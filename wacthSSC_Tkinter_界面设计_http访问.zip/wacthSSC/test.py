# _*_coding:utf-8 _*_
__author__ = 'CHENYUANYINGSHI'

import urllib,urllib2

image=urllib.urlopen('http://www.robit918.com/index.php/user/vcode/1471663773').read()
f=open('C:/Users/Administrator/Desktop/2.png','wb')

f.write(image)
print(image)

