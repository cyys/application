#coding=utf-8
__author__ = 'CHENYUANYINGSHI'

import ConfigParser,urllib,urllib2,urlparse,time,re

def addAjaxHeads(req):
    req.add_header('Accept','application/json, text/javascript, */*; q=0.01')
    req.add_header('Accept-Encoding','gzip, deflate')
    req.add_header('Accept-Language','zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3')
    req.add_header('Connection','keep-alive')
    req.add_header('Content-Type','application/x-www-form-urlencoded; charset=UTF-8')
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0')
    req.add_header('X-Requested-With','XMLHttpRequest')
    req.add_header('x-form-call','1')


def addCommonHead(req):
    req.add_header('Accept','text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
    req.add_header('Accept-Encoding','gzip, deflate')
    req.add_header('Accept-Language','zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3')
    req.add_header('Cache-Control','no-cache')
    req.add_header('Connection','keep-alive')
    req.add_header('Pragma','no-cache')
    req.add_header('Upgrade-Insecure-Requests','1')
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0')



class readCoreConfig():
    def __init__(self):
        self._cf=ConfigParser.ConfigParser()
        self._cf.read('core.ini')

    def getConfig(self):
        return self._cf

coreIni=readCoreConfig()
def visitorLoginGUI():
    baseUrl=coreIni.getConfig().get('core','baseUrl')
    loginGUIUrl=coreIni.getConfig().get('core','loginGUIUrl')
    req=urllib2.Request(baseUrl+loginGUIUrl)
    addCommonHead(req)
    res=urllib2.urlopen(req)
    # print(res.read())
    return res.headers['set-cookie']

def readCheckImage(cookies):
    baseUrl=coreIni.getConfig().get('core','baseUrl')
    checkImage=coreIni.getConfig().get('core','checkImage')
    req=urllib2.Request(baseUrl+checkImage+str(time.time()))
    req.add_header('Cookie',cookies)
    addCommonHead(req)
    res=urllib2.urlopen(req)
    file=open('vcode.png','wb')
    file.write(res.read())
    file.close()
    return res.headers['set-cookie']

def loginSystem(param,cookies):
    baseUrl=coreIni.getConfig().get('core','baseUrl')
    loginUrl=coreIni.getConfig().get('core','loginUrl')
    req=urllib2.Request(baseUrl+loginUrl)
    req.add_header('Cookie',cookies)
    addAjaxHeads(req)
    postData=urllib.urlencode(param).encode('utf-8')
    res=urllib2.urlopen(req,postData)
    # print(postData)
    # print(res.headers)
    return res.headers['set-cookie']

def  takeHao123():
    res=urllib2.urlopen('http://www.hao123.com')
    html=res.read()
    mt=re.compile('<a .*?>.*?</a>')
    hs=mt.findall(html)
    for i in range(len(hs)):
        print(hs[i].decode('utf-8'))



    # print('\xe8\xae\xbe\xe4\xb8\xba\xe9\xa6\x96\xe9\xa1\xb5'.decode('utf-8'))



if __name__=='__main__':
    # cks=visitorLoginGUI()
    # ckss=readCheckImage(cks)
    # print(cks)
    # print(ckss)
    # loginSystem({'username':'反反复复','password':'cy198612072100','vcode':'8417'},ckss)

    # takeHao123()
    print([i  for i in range(1,10)])






