# _*_coding:utf-8 _*_
__author__ = 'CHENYUANYINGSHI'



import math,coreHttp
from Tkinter import *
from PIL import Image,ImageTk

loginSysCookie=None

'''
窗口提示信息
'''
def addToolNameLabel(top):
    frm=Frame(top)
    Label(frm,text='时时彩自动分析工具',font=("宋体", 16), width=20, height=2).pack(side=LEFT)
    frm.pack(side=TOP)

'''
用户名 和 密码
'''
def addBaseLabel(top):
    frm=Frame(top)
    lf=LabelFrame(frm)
    Label(lf,text='用户名：',font=("宋体", 13), width=10, height=1).grid(row=0,column=0)
    Label(lf,text='密 码：',font=("宋体", 13), width=10, height=1).grid(row=1,column=0)

    lf.pack(side=LEFT)

    rf=LabelFrame(frm)
    userName=StringVar()
    Entry(rf,textvariable=userName,width=55).grid(row=0,column=1)
    passWord=StringVar()
    Entry(rf,textvariable=passWord,width=55,show='*').grid(row=1,column=1)

    rf.pack(side=LEFT)
    frm.pack()

    return {'userName':userName,'passWord':passWord}

def changeImage(checkImage,cookieGUI):
    loginSysCookie=coreHttp.readCheckImage(cookieGUI)
    pt='vcode.png'
    img=Image.open(pt)
    pho=ImageTk.PhotoImage(img)
    checkImage['image']=pho
    checkImage['height']=20
    raise '换图片'

def addLoginBtn(top,inputData):
    frm=Frame(top)
    Button(frm,text='登   录',width=50,command=lambda :loginToSystem(top,inputData)).pack(side=RIGHT)
    frm.pack()

def loginToSystem(top,inputData):
    param={'username':inputData['userName'].get(),'password':inputData['passWord'].get(),'vcode':inputData['vcode'].get()}
    coreHttp.loginSystem(param,loginSysCookie)
    # top.quit()


def addBaseInfo(top):
    frm=Frame(top)
    Label(frm,text='作者：尘缘影世(QQ:304355188)；工作室：颖行工作室',font=("宋体", 13), width=50, height=1).grid(row=0,column=0)
    frm.pack(side=BOTTOM)

def loginGUI():
    #顶级窗口
    top=Tk()
    top.title('时时彩自动分析工具')
    top.resizable(width=False,height=False)
    curHeight=300

    curWidth=500
    width,height=top.maxsize()
    positon='%dx%d+%d+%d'%(curWidth,curHeight,math.floor ((width-curWidth)/2),math.floor ((height-curHeight)/2))
    top.geometry(positon)

    addToolNameLabel(top)
    inputData=addBaseLabel(top)

    #添加验证码显示区域
    yzm=Frame(top)
    frms=LabelFrame(yzm)
    Label(frms,text='验证码：',font=("宋体", 13), width=10, height=1).grid(row=0,column=0)
    frms.pack(side=LEFT)

    frmis=LabelFrame(yzm)
    vcode=StringVar()
    inputData['vcode']=vcode
    Entry(frmis,textvariable=vcode,width=25).grid(row=0,column=0)
    checkImage=Label(frmis,image=None, width=150,height=2)
    checkImage.grid(row=0,column=1)

    cookieGUI=coreHttp.visitorLoginGUI()
    # loginSysCookie=cookieGUI

    chb=Button(frmis,text='更换图片',command=lambda :changeImage(checkImage,cookieGUI))
    chb.grid(row=0,column=2)
    chb.invoke()

    frmis.pack(side=LEFT)
    yzm.pack()

    #添加登录按钮
    addLoginBtn(top,inputData)

    #开发者信息
    addBaseInfo(top)

# print('{0[name]:s} is name'.format({'name':'TTT'}))
# print('{name:s} is name'.format(**{'name':'TTT'}))

    top.mainloop()

if __name__=='__main__':
    loginGUI()







