__author__ = 'CHENYUANYINGSHI'
import urllib.request as req
import _thread

if __name__=='__main__':
    print('__main__')

    '''
    有关正则表达式

    '''
    import re
    a=re.search('^w\w+a$','weqa')
    print(a.pos)

    '''
        爬网页
    '''
    request=req.Request('http://www.hao123.com/')
    res=req.urlopen(request)
    html =res.readall().decode('utf-8')
    print(html.rfind('<title>'))
    print(res.getheaders())

    allTitle=re.findall('>(.*?)<',html,re.S)
    print(allTitle)
    print(len(allTitle))
    for at in allTitle:
        if(at.find('天气')>-1):
           print(at)


    '''
        类似java一样线程使用方法
    '''
    import threading
    class Task1(threading.Thread):
        def run(self):
            name=threading.current_thread().getName()
            name+='='
            i=0
            while i<1000:
                print(name,i)
                i+=1

    i=0
    threadList=[]
    while i<100:
        t1=Task1()
        i+=1
        threadList.append(t1)
        t1.start()

    for t in threadList:
          t.join()

    '''
        线程，比较底层的
    '''

    def printInfo(var,t):
        for p in var:
            print(p)

    _thread.start_new_thread(printInfo,(('1111111111',111,22), 2))
    while True:
        pass








