__author__ = 'CHENYUANYINGSHI'

if __name__=='__main__':
    print('-----------------')

    '''
    模拟浏览器访问

    '''
    # import http.client as client
    # con=client.HTTPConnection('www.hao123.com')
    # con.request('GET','')
    # res=con.getresponse()
    # html=res.read().decode('utf-8')
    # print(html)
    # print(res.getheaders())


    '''
    python系统内置的方法、关键词
    '''

    # import builtins
    # import keyword
    # tem=dir(builtins)
    # for p in tem:
    #     print(p)
    # print(tem)
    # tem=keyword.kwlist
    # for p in tem:
    #     print(p)
    # print(tem)


    '''
        webservice客户端调用java服务端
        testAxis2\src\TestAxis2.java
    '''
    import suds.client as client
    # print(client)
    # tem=dir(client)
    # for p in tem:
    #     print(p)

    url = "http://localhost:8080/axis2/services/TestAxis2?wsdl"
    ct = client.Client(url)

    result=ct.service.sayHello()
    print(result)
    result=ct.service.sayHelloToPerson(' CCTV ')
    print(result)
