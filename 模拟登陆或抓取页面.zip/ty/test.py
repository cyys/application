__author__ = 'cheny'
import urllib.request as request
import urllib.parse as parse
import json,re,timeit,threading,_thread,time
HOST='120.55.181.157:81'
# HOST='localhost:8081'

def findData():
    url='http://'+HOST+'/guos/sys/emp/list'
    data={'currentPage':1,'empNo':'','limit':10,'method':'$.ras.toPage',
          'name':'','orgId':'','orgname':'','sex':''}
    param=parse.urlencode(data).encode('UTF-8')

    noLogin=True

    while True:
        if noLogin:
            head=visitorLogin()
            cookies=loginSystem(head)
        req=request.Request(url)
        req.add_header('Cookie',head)
        for cookies in cookies:
            req.add_header('Cookie',cookies[1])
        res=request.urlopen(req,param)
        jsonStr=res.read().decode('UTF-8')
        js=json.loads(jsonStr)
        noLogin=not js['success']
        print('data:',js['success'])

def findDataOnce(var=None,i=None):
    url='http://'+HOST+'/guos/sys/emp/list'
    data={'currentPage':1,'empNo':'','limit':10,'method':'$.ras.toPage',
          'name':'','orgId':'','orgname':'','sex':''}
    param=parse.urlencode(data).encode('UTF-8')

    head=visitorLogin()
    cookies=loginSystem(head)
    req=request.Request(url)
    req.add_header('Cookie',head)
    for cookies in cookies:
        req.add_header('Cookie',cookies[1])
    res=request.urlopen(req,param)
    jsonStr=res.read().decode('UTF-8')
    js=json.loads(jsonStr)
    print(threading.current_thread().getName()+'_'+'data:',js['success'])
    global noFinishs
    if len(noFinishs)==(i+1):
        noFinishs[i]=False

def loginSystem(head):
    checkAdmin='http://'+HOST+'/guos/checkAdmin'
    data={'nameAdmin':'admin','nameAdmin2':'12345678','captcha':''}
    param=parse.urlencode(data).encode('UTF-8')
    req=request.Request(checkAdmin)
    req.add_header('Cookie',head)
    res=request.urlopen(req,param)
    jsonStr=res.read().decode('UTF-8')
    js=json.loads(jsonStr)
    print('login:',js['success'])
    cookies=[]
    headers=res.getheaders()
    cookies.append(headers[1])
    cookies.append(headers[2])
    return cookies

def visitorLogin():
    loginHtml='http://'+HOST+'/guos/admin'
    req=request.Request(loginHtml)
    res=request.urlopen(req)
    print('========visitorLogin=========')
    return res.getheaders()[2][1]

def loginSystemOnly():
    checkAdmin='http://'+HOST+'/guos/checkAdmin'
    while(True):
        data={'nameAdmin':'admin','nameAdmin2':'12345678','captcha':''}
        param=parse.urlencode(data).encode('UTF-8')
        req=request.Request(checkAdmin)
        res=request.urlopen(req,param)
        jsonStr=res.read().decode('UTF-8')
        js=json.loads(jsonStr)
        print(threading.current_thread().getName()+':'+str(js['success']))

def loginSystemOnce(i,x):
    checkAdmin='http://'+HOST+'/guos/checkAdmin'
    data={'nameAdmin':'admin','nameAdmin2':'12345678','captcha':''}
    param=parse.urlencode(data).encode('UTF-8')
    req=request.Request(checkAdmin)
    res=request.urlopen(req,param)
    jsonStr=res.read().decode('UTF-8')
    js=json.loads(jsonStr)
    print(threading.current_thread().getName()+':'+str(js['success']))
    global noFinishs
    if len(noFinishs)==(i+1):
        noFinishs[i]=False

def lookUp(var=None,tem=None):
    ms=dir(var)
    str=''
    count=1
    for m in ms:
        if count%8!=0:
            str+=m+','
        else:
            print(str)
            str=''
        count+=1
    if len(ms)%8!=0:
        print(str)

def lookUp1(i,max):
    print(i)
    ms=dir(max[0])
    str=''
    count=1
    for m in ms:
        if count%8!=0:
            str+=m+','
        else:
            # print(str)
            str=''
        count+=1
    # if len(ms)%8!=0:
    #     print(str)
    global noFinishs
    print(threading.current_thread().getName())
    noFinishs[i]=False

#JSESSIONID=E8C4066FFAC68933BD284F1F1C91C564; Path=/guos/; HttpOnly
if __name__=='__main__':
    # lookUp(OSError)
    #t=timeit.Timer('findData()','from __main__ import findData')
    #print(t.timeit(1))
    # lookUp(_thread.start_new_thread)
    noFinishs=[]
    i=0
    print(threading.current_thread().getName())
    while i<500:
        time.sleep(0.1)
        try:
            noFinishs.append(True)
            _thread.start_new_thread(findDataOnce,(i,'1'))
        except:
            print(str(i)+'==========================================')
            time.sleep(10)
        i+=1
    noFinish=True
    while noFinish:
        if True not in noFinishs:
            noFinish=False